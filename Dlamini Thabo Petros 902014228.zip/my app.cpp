Dart

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(const MyCVApp());
}

class MyCVApp extends StatelessWidget {
  const MyCVApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'My Personal CV',
      theme: ThemeData(
        primaryColor: const Color(0xFF172B4D),
        scaffoldBackgroundColor: const Color(0xFFF4F6FA),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF172B4D),
        ),
        useMaterial3: true,
      ),
      home: const CVHomePage(),
    );
  }
}

class CVHomePage extends StatefulWidget {
  const CVHomePage({super.key});

  @override
  State<CVHomePage> createState() => _CVHomePageState();
}

class _CVHomePageState extends State<CVHomePage> {
  int selectedIndex = 0;

  final List<Widget> pages = const [
    HomeScreen(),
    SkillsScreen(),
    ExperienceScreen(),
    EducationScreen(),
    ContactScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[selectedIndex],
      bottomNavigationBar: NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: (index) {
          setState(() {
            selectedIndex = index;
          });
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.code),
            label: 'Skills',
          ),
          NavigationDestination(
            icon: Icon(Icons.work_outline),
            label: 'Experience',
          ),
          NavigationDestination(
            icon: Icon(Icons.school_outlined),
            label: 'Education',
          ),
          NavigationDestination(
            icon: Icon(Icons.contact_mail_outlined),
            label: 'Contact',
          ),
        ],
      ),
    );
  }
}

// REUSABLE SECTION TITLE

Widget sectionTitle(String title) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 12),
    child: Text(
      title,
      style: const TextStyle(
        fontSize: 22,
        fontWeight: FontWeight.bold,
        color: Color(0xFF172B4D),
      ),
    ),
  );
}

// HOME / PROFILE SCREEN

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          const SizedBox(height: 35),

          const CircleAvatar(
            radius: 65,
            backgroundColor: Color(0xFF172B4D),
            backgroundImage: AssetImage('assets/images/profile.jpg'),
          ),

          const SizedBox(height: 20),

          const Text(
            'YOUR FULL NAME',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 26,
              fontWeight: FontWeight.bold,
              color: Color(0xFF172B4D),
            ),
          ),

          const SizedBox(height: 8),

          const Text(
            'Flutter Developer | IT Student',
            style: TextStyle(
              fontSize: 16,
              color: Colors.blueGrey,
            ),
          ),

          sectionTitle('About Me'),

          const Card(
            child: Padding(
              padding: EdgeInsets.all(18),
              child: Text(
                'I am a dedicated and motivated IT student '
                'with an interest in mobile application development, '
                'programming and technology. I enjoy learning '
                'new skills and solving problems through technology.',
                textAlign: TextAlign.justify,
                style: TextStyle(fontSize: 15, height: 1.6),
              ),
            ),
          ),

          sectionTitle('Personal Information'),

          const InfoCard(
            icon: Icons.person,
            title: 'Full Name',
            value: 'Your Full Name',
          ),

          const InfoCard(
            icon: Icons.location_on,
            title: 'Location',
            value: 'Eswatini',
          ),

          const InfoCard(
            icon: Icons.computer,
            title: 'Profession',
            value: 'IT Student',
          ),
        ],
      ),
    );
  }
}

// SKILLS SCREEN

class SkillsScreen extends StatelessWidget {
  const SkillsScreen({super.key});

  Widget skill(String name, double level) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              name,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 10),
            LinearProgressIndicator(
              value: level,
              minHeight: 8,
              borderRadius: BorderRadius.circular(10),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 30),
          sectionTitle('My Technical Skills'),

          skill('Flutter', 0.75),
          skill('Dart Programming', 0.70),
          skill('HTML & CSS', 0.80),
          skill('Java', 0.60),
          skill('Database Management', 0.65),

          sectionTitle('Soft Skills'),

          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: const [
              Chip(label: Text('Communication')),
              Chip(label: Text('Teamwork')),
              Chip(label: Text('Problem Solving')),
              Chip(label: Text('Creativity')),
              Chip(label: Text('Time Management')),
              Chip(label: Text('Leadership')),
            ],
          ),
        ],
      ),
    );
  }
}

// EXPERIENCE SCREEN

class ExperienceScreen extends StatelessWidget {
  const ExperienceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 30),
          sectionTitle('My Experience'),

          const ExperienceCard(
            title: 'Personal CV Application',
            company: 'Academic Project',
            period: '2026',
            description:
                'Developed a personal CV mobile application '
                'using Flutter and Dart. Implemented navigation, '
                'profile information and interactive contact links.',
          ),

          const ExperienceCard(
            title: 'Website Design',
            company: 'Academic Project',
            period: '2026',
            description:
                'Designed website interfaces and practised '
                'HTML, CSS and user interface development.',
          ),

          const ExperienceCard(
            title: 'Programming Practice',
            company: 'Academic Learning',
            period: '2026',
            description:
                'Practised programming concepts, problem solving '
                'and application development.',
          ),
        ],
      ),
    );
  }
}

// EDUCATION SCREEN

class EducationScreen extends StatelessWidget {
  const EducationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 30),
          sectionTitle('Education'),

          const InfoCard(
            icon: Icons.school,
            title: 'Qualification',
            value: 'Information Technology Student',
          ),

          const InfoCard(
            icon: Icons.account_balance,
            title: 'Institution',
            value: 'Your Institution Name',
          ),

          const InfoCard(
            icon: Icons.calendar_today,
            title: 'Study Period',
            value: '2025 - Present',
          ),

          sectionTitle('Certifications'),

          const InfoCard(
            icon: Icons.verified,
            title: 'Programming',
            value: 'Add your programming certificates here',
          ),

          const InfoCard(
            icon: Icons.workspace_premium,
            title: 'Other Certificates',
            value: 'Add relevant certificates here',
          ),
        ],
      ),
    );
  }
}

// CONTACT SCREEN

class ContactScreen extends StatelessWidget {
  const ContactScreen({super.key});

  Future<void> openLink(String link) async {
    final Uri uri = Uri.parse(link);

    if (!await launchUrl(
      uri,
      mode: LaunchMode.externalApplication,
    )) {
      debugPrint('Could not open $link');
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 30),
          sectionTitle('Contact Me'),

          const Text(
            'Feel free to contact me through any of the '
            'following platforms.',
            style: TextStyle(fontSize: 15),
          ),

          const SizedBox(height: 20),

          ContactCard(
            icon: Icons.email,
            title: 'Email',
            value: 'yourname@gmail.com',
            onTap: () {
              openLink('mailto:yourname@gmail.com');
            },
          ),

          ContactCard(
            icon: Icons.phone,
            title: 'Phone',
            value: '+268 76000000',
            onTap: () {
              openLink('tel:+26876000000');
            },
          ),

          ContactCard(
            icon: Icons.language,
            title: 'LinkedIn',
            value: 'Visit my LinkedIn profile',
            onTap: () {
              openLink('https://www.linkedin.com/');
            },
          ),

          ContactCard(
            icon: Icons.code,
            title: 'GitHub',
            value: 'Visit my GitHub profile',
            onTap: () {
              openLink('https://github.com/');
            },
          ),
        ],
      ),
    );
  }
}

// REUSABLE INFORMATION CARD

class InfoCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;

  const InfoCard({
    super.key,
    required this.icon,
    required this.title,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 7),
      child: ListTile(
        leading: Icon(
          icon,
          color: const Color(0xFF172B4D),
          size: 28,
        ),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(value),
      ),
    );
  }
}

// REUSABLE EXPERIENCE CARD

class ExperienceCard extends StatelessWidget {
  final String title;
  final String company;
  final String period;
  final String description;

  const ExperienceCard({
    super.key,
    required this.title,
    required this.company,
    required this.period,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 10),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color(0xFF172B4D),
              ),
            ),
            const SizedBox(height: 5),
            Text(company),
            Text(
              period,
              style: const TextStyle(color: Colors.blueGrey),
            ),
            const Divider(height: 25),
            Text(
              description,
              style: const TextStyle(height: 1.5),
            ),
          ],
        ),
      ),
    );
  }
}

// REUSABLE CONTACT CARD

class ContactCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;
  final VoidCallback onTap;

  const ContactCard({
    super.key,
    required this.icon,
    required this.title,
    required this.value,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 9),
      child: ListTile(
        onTap: onTap,
        leading: Icon(
          icon,
          color: const Color(0xFF172B4D),
          size: 30,
        ),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text(value),
        trailing: const Icon(Icons.open_in_new),
      ),
    );
  }
}
